import * as THREE from 'three';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader';

const stlLoader = new STLLoader();

document.getElementById('uploadButton').addEventListener('click', handleFileUpload);

function handleFileUpload() {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];

    if (!file) {
        alert("Please select an STL file to upload.");
        return;
    }

    const reader = new FileReader();
    reader.onload = function(event) {
        const arrayBuffer = event.target.result;
        const geometry = stlLoader.parse(arrayBuffer);
        createCard(geometry);
    };
    reader.readAsArrayBuffer(file);
}

function createCard(geometry) {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');

    // Set up Three.js scene for rendering
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true });
    renderer.setSize(200, 200); // Set the size of the canvas

    const material = new THREE.MeshStandardMaterial({ color: 0x555555 });
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    // Center the model
    geometry.computeBoundingBox();
    const center = new THREE.Vector3();
    geometry.boundingBox.getCenter(center);
    mesh.position.sub(center); // Center the mesh

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    const pointLight = new THREE.PointLight(0xffffff, 1);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    camera.position.z = 5;

    // Render the scene
    renderer.render(scene, camera);

    // Convert canvas to image and create a card
    const img = new Image();
    img.src = canvas.toDataURL();
    img.onload = function() {
        const card = document.createElement('div');
        card.classList.add('card');

        const cardImage = document.createElement('img');
        cardImage.src = img.src;
        cardImage.alt = "3D Model Preview";

        const cardTitle = document.createElement('div');
        cardTitle.classList.add('card-title');
        cardTitle.innerText = "3D Model";

        card.appendChild(cardImage);
        card.appendChild(cardTitle);

        document.getElementById('cardContainer').appendChild(card);
    };
}